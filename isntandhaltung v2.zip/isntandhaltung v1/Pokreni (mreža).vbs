' Kao Pokreni.vbs, ali kolege u lokalnoj mreži mogu prijavljivati zahtjeve (vide samo stranicu /prijava).
' Adresa za kolege zapisana je u datoteci odrzavanje.log.
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
mapa = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = mapa
sh.Run "pythonw """ & mapa & "\app.py"" --mreza", 0, False
