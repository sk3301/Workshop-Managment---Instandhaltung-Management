@echo off
rem Pokretanje uz prijavu zahtjeva s drugih racunala u lokalnoj mrezi.
rem Ostala racunala vide SAMO stranicu /prijava; sve ostalo je dostupno samo na ovom racunalu.
cd /d "%~dp0"
python -c "import flask" 2>nul || python -m pip install -r requirements.txt
python app.py --mreza
pause
