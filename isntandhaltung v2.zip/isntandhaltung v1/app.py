"""Evidencija održavanja i ispitivanja strojeva i uređaja.

Lokalna web aplikacija (Flask + SQLite). Pokretanje:  python app.py
Zatim otvorite http://127.0.0.1:5000 u pregledniku.
"""
import json
import os
import shutil
import sqlite3
import sys
import uuid
import webbrowser
from calendar import monthrange
from datetime import date, datetime

from flask import (Flask, abort, flash, g, jsonify, redirect, request, send_from_directory, url_for)
from flask import render_template as flask_render_template

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("ODRZAVANJE_DB", os.path.join(BASE_DIR, "odrzavanje.db"))
DOK_DIR = os.environ.get("ODRZAVANJE_DOKUMENTI", os.path.join(BASE_DIR, "dokumenti"))

app = Flask(__name__)
app.secret_key = "odrzavanje-lokalna-aplikacija"
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024

SCHEMA = """
CREATE TABLE IF NOT EXISTS klijenti (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naziv TEXT NOT NULL,
    oib TEXT, adresa TEXT, grad TEXT, kontakt_osoba TEXT,
    telefon TEXT, email TEXT, napomena TEXT,
    kreirano TEXT DEFAULT (date('now'))
);
CREATE TABLE IF NOT EXISTS uredaji (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    klijent_id INTEGER REFERENCES klijenti(id),
    naziv TEXT NOT NULL,
    vrsta TEXT, proizvodjac TEXT, model TEXT, serijski_broj TEXT,
    inventarni_broj TEXT, godina_proizvodnje INTEGER, lokacija TEXT,
    interval_odrzavanja INTEGER, interval_ispitivanja INTEGER,
    napomena TEXT, aktivan INTEGER DEFAULT 1,
    kreirano TEXT DEFAULT (date('now'))
);
CREATE TABLE IF NOT EXISTS odrzavanja (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uredaj_id INTEGER NOT NULL REFERENCES uredaji(id) ON DELETE CASCADE,
    datum TEXT NOT NULL,
    sljedeci_datum TEXT,
    vrsta TEXT, opis TEXT, izvrsio TEXT, trosak REAL, napomena TEXT
);
CREATE TABLE IF NOT EXISTS predlosci (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naziv TEXT NOT NULL,
    opis TEXT,
    stavke TEXT,
    interval_mj INTEGER
);
CREATE TABLE IF NOT EXISTS ispitivanja (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uredaj_id INTEGER NOT NULL REFERENCES uredaji(id) ON DELETE CASCADE,
    predlozak_id INTEGER REFERENCES predlosci(id) ON DELETE SET NULL,
    broj_zapisnika TEXT,
    vrsta TEXT,
    datum TEXT NOT NULL,
    sljedeci_datum TEXT,
    ispitivac TEXT,
    rezultat TEXT,
    napomena TEXT,
    stavke_json TEXT
);
CREATE TABLE IF NOT EXISTS postavke (
    kljuc TEXT PRIMARY KEY,
    vrijednost TEXT
);
CREATE TABLE IF NOT EXISTS formulari (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naziv TEXT NOT NULL,
    opis TEXT,
    polja_json TEXT
);
CREATE TABLE IF NOT EXISTS vrste_uredaja (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naziv TEXT NOT NULL UNIQUE COLLATE NOCASE
);
CREATE TABLE IF NOT EXISTS zahtjevi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naslov TEXT NOT NULL,
    opis TEXT,
    podnositelj TEXT, kontakt TEXT, lokacija TEXT,
    uredaj_id INTEGER REFERENCES uredaji(id) ON DELETE SET NULL,
    datum_prijave TEXT DEFAULT (datetime('now', 'localtime')),
    prioritet INTEGER DEFAULT 0,
    izvrsen INTEGER DEFAULT 0,
    datum_izvrsenja TEXT,
    napomena_izvrsenja TEXT
);
CREATE TABLE IF NOT EXISTS izbornici (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naziv TEXT NOT NULL,
    opis TEXT,
    poveznica TEXT,
    poredak INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS dokumenti (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naziv TEXT NOT NULL,
    opis TEXT,
    datoteka TEXT NOT NULL,
    izvorno_ime TEXT,
    uredaj_id INTEGER REFERENCES uredaji(id) ON DELETE CASCADE,
    izbornik_id INTEGER,
    datum TEXT DEFAULT (date('now'))
);
CREATE TABLE IF NOT EXISTS formular_zapisi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    formular_id INTEGER REFERENCES formulari(id) ON DELETE SET NULL,
    naziv TEXT,
    uredaj_id INTEGER REFERENCES uredaji(id) ON DELETE CASCADE,
    datum TEXT,
    popunio TEXT,
    napomena TEXT,
    polja_json TEXT
);
CREATE TABLE IF NOT EXISTS inventar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naziv TEXT NOT NULL,
    sifra TEXT, kategorija TEXT,
    kolicina REAL DEFAULT 0,
    jedinica TEXT, min_kolicina REAL, lokacija TEXT,
    cijena REAL, dobavljac TEXT, napomena TEXT
);
CREATE TABLE IF NOT EXISTS inventar_promjene (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    artikl_id INTEGER NOT NULL REFERENCES inventar(id) ON DELETE CASCADE,
    datum TEXT NOT NULL,
    vrsta TEXT,
    promjena REAL,
    stanje REAL,
    opis TEXT
);
CREATE TABLE IF NOT EXISTS eksterni_servisi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uredaj_id INTEGER NOT NULL REFERENCES uredaji(id) ON DELETE CASCADE,
    broj_naloga TEXT,
    servis_naziv TEXT NOT NULL,
    servis_adresa TEXT, servis_kontakt TEXT, servis_telefon TEXT,
    datum_slanja TEXT NOT NULL,
    ocekivani_povratak TEXT,
    opis_kvara TEXT, pribor TEXT, predao TEXT, napomena TEXT,
    datum_povratka TEXT,
    izvrseni_radovi TEXT, trosak REAL, broj_racuna TEXT, preuzeo TEXT
);
"""

ZADANE_POSTAVKE = {
    "naziv_tvrtke": "Meine Firma GmbH",
    "adresa_tvrtke": "",
    "oib_tvrtke": "",
    "telefon_tvrtke": "",
    "email_tvrtke": "",
    "dani_upozorenja": "30",
    "jezik": "de",
}

ZADANE_VRSTE = ["Werkzeugmaschine", "Kompressor", "Druckbehälter", "Kran", "Gabelstapler",
                "Elektrogerät", "Ofen", "Lüftung / Klima", "Aggregat"]

ZADANI_PREDLOSCI = [
    ("Prüfung von Arbeitsmitteln",
     "Wiederkehrende Prüfung von Arbeitsmitteln (sichere Verwendung).",
     "Schutzeinrichtungen und Abdeckungen\nBedienelemente und Kennzeichnungen\nNot-Halt-Einrichtung\n"
     "Warn- und Sicherheitskennzeichnung\nStandsicherheit und Befestigung der Maschine\nLärm und Vibration\n"
     "Beleuchtung des Arbeitsplatzes\nBetriebsanweisung am Arbeitsplatz vorhanden", 24),
    ("Prüfung der elektrischen Sicherheit",
     "Prüfung der elektrischen Anlage / des elektrischen Teils der Maschine.",
     "Sichtprüfung von Leitungen und Anschlüssen\nDurchgängigkeit des Schutzleiters\nIsolationswiderstand\n"
     "Schleifenimpedanz\nPrüfung der Fehlerstrom-Schutzeinrichtung (RCD)\nFunktion des Hauptschalters", 24),
    ("Prüfung Druckbehälter",
     "Wiederkehrende Prüfung von Druckbehältern / Kompressoren.",
     "Sichtprüfung der Behälterwand\nSicherheitsventil\nManometer\nDruckprobe\n"
     "Dichtungen, Verbindungen und Leitungen\nKondensatablass", 12),
    ("Prüfung Kran / Hebezeug",
     "Wiederkehrende Prüfung von Lastaufnahmeeinrichtungen.",
     "Tragkonstruktion\nSeile / Ketten\nHaken und Hakensicherungen\nBremsen\nEndschalter\n"
     "Steuerung und Not-Halt-Taster\nProbebelastung", 12),
]


# ---------------------------------------------------------------- baza

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def q(sql, args=(), one=False):
    rows = db().execute(sql, args).fetchall()
    if one:
        return rows[0] if rows else None
    return rows


def x(sql, args=()):
    cur = db().execute(sql, args)
    db().commit()
    return cur.lastrowid


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    # nadogradnja postojeće baze: stupci dodani u kasnijim verzijama
    stupci = {r[1] for r in conn.execute("PRAGMA table_info(formulari)")}
    if "izbornik_id" not in stupci:
        conn.execute("ALTER TABLE formulari ADD COLUMN izbornik_id INTEGER")
    for k, v in ZADANE_POSTAVKE.items():
        conn.execute("INSERT OR IGNORE INTO postavke (kljuc, vrijednost) VALUES (?, ?)", (k, v))
    if conn.execute("SELECT COUNT(*) FROM vrste_uredaja").fetchone()[0] == 0:
        conn.executemany("INSERT OR IGNORE INTO vrste_uredaja (naziv) VALUES (?)",
                         [(v,) for v in ZADANE_VRSTE])
        conn.execute("""INSERT OR IGNORE INTO vrste_uredaja (naziv)
                        SELECT DISTINCT TRIM(vrsta) FROM uredaji WHERE TRIM(COALESCE(vrsta, '')) <> ''""")
    if conn.execute("SELECT COUNT(*) FROM predlosci").fetchone()[0] == 0:
        conn.executemany("INSERT INTO predlosci (naziv, opis, stavke, interval_mj) VALUES (?, ?, ?, ?)",
                         ZADANI_PREDLOSCI)
    conn.commit()
    conn.close()


def postavke():
    if "postavke" not in g:
        g.postavke = {r["kljuc"]: r["vrijednost"] for r in q("SELECT * FROM postavke")}
    return g.postavke


def dani_upozorenja():
    try:
        return int(postavke().get("dani_upozorenja") or 30)
    except ValueError:
        return 30


# ---------------------------------------------------------------- jezik (Deutsch / Hrvatski)

JEZICI = {"de": "Deutsch", "hr": "Hrvatski"}


@app.before_request
def odaberi_jezik():
    """Jezik se pamti po pregledniku (kolačić); bez kolačića vrijedi zadani jezik iz postavki."""
    j = request.cookies.get("jezik")
    if j not in JEZICI:
        try:
            j = postavke().get("jezik")
        except sqlite3.Error:
            j = None
    g.jezik = j if j in JEZICI else "de"


def jezik():
    return getattr(g, "jezik", "de") if g else "de"


def t(de, hr):
    return hr if jezik() == "hr" else de


def render_template(ime, **ctx):
    # hrvatske stranice su u templates/hr/ s istim imenima
    return flask_render_template(("hr/" if jezik() == "hr" else "") + ime, **ctx)


@app.route("/jezik/<kod>")
def promijeni_jezik(kod):
    natrag = request.args.get("natrag") or url_for("pocetna")
    if not natrag.startswith("/") or natrag.startswith("//"):
        natrag = url_for("pocetna")
    odg = redirect(natrag)
    if kod in JEZICI:
        odg.set_cookie("jezik", kod, max_age=10 * 365 * 24 * 3600, samesite="Lax")
    return odg


# ---------------------------------------------------------------- pomoćne

def add_months(d, months):
    m = d.month - 1 + months
    y = d.year + m // 12
    m = m % 12 + 1
    return date(y, m, min(d.day, monthrange(y, m)[1]))


def parse_date(s):
    try:
        return date.fromisoformat(s) if s else None
    except ValueError:
        return None


def form_data(fields, ints=(), floats=(), checkboxes=()):
    data = {}
    for f in fields:
        if f in checkboxes:
            data[f] = 1 if request.form.get(f) else 0
            continue
        v = (request.form.get(f) or "").strip()
        if not v:
            data[f] = None
        elif f in ints:
            try:
                data[f] = int(v)
            except ValueError:
                data[f] = None
        elif f in floats:
            try:
                data[f] = float(v.replace(",", "."))
            except ValueError:
                data[f] = None
        else:
            data[f] = v
    return data


def insert(table, data):
    cols = ", ".join(data)
    marks = ", ".join("?" for _ in data)
    return x(f"INSERT INTO {table} ({cols}) VALUES ({marks})", tuple(data.values()))


def update(table, row_id, data):
    sets = ", ".join(f"{k} = ?" for k in data)
    x(f"UPDATE {table} SET {sets} WHERE id = ?", (*data.values(), row_id))


def get_or_404(table, row_id):
    row = q(f"SELECT * FROM {table} WHERE id = ?", (row_id,), one=True)
    if row is None:
        abort(404)
    return row


def provjeri_datume(data):
    """Vraća poruku o grešci ili None."""
    if not data.get("datum") or not parse_date(data["datum"]):
        return t("Das Datum ist erforderlich.", "Datum je obavezan.")
    if data.get("sljedeci_datum"):
        sl = parse_date(data["sljedeci_datum"])
        if not sl:
            return t("Ungültiges Datum des nächsten Termins.", "Neispravan datum sljedećeg roka.")
        if sl < parse_date(data["datum"]):
            return t("Der nächste Termin darf nicht vor dem Durchführungsdatum liegen.", "Sljedeći rok ne može biti prije datuma izvršenja.")
    return None


def status_roka(sljedeci):
    d = parse_date(sljedeci)
    if not d:
        return None, None
    dani = (d - date.today()).days
    if dani < 0:
        return "istekao", dani
    if dani <= dani_upozorenja():
        return "uskoro", dani
    return "ok", dani


RokoviSQL = """
SELECT * FROM (
  SELECT 'odrzavanje' AS tip, o.id AS zapis_id, o.uredaj_id, o.datum, o.sljedeci_datum, o.vrsta,
         u.naziv AS uredaj, u.serijski_broj, u.lokacija, k.id AS klijent_id, k.naziv AS klijent
  FROM odrzavanja o
  JOIN uredaji u ON u.id = o.uredaj_id
  LEFT JOIN klijenti k ON k.id = u.klijent_id
  WHERE u.aktivan = 1 AND o.sljedeci_datum IS NOT NULL
    AND o.id = (SELECT o2.id FROM odrzavanja o2
                WHERE o2.uredaj_id = o.uredaj_id AND o2.sljedeci_datum IS NOT NULL
                ORDER BY o2.datum DESC, o2.id DESC LIMIT 1)
  UNION ALL
  SELECT 'ispitivanje', i.id, i.uredaj_id, i.datum, i.sljedeci_datum, i.vrsta,
         u.naziv, u.serijski_broj, u.lokacija, k.id, k.naziv
  FROM ispitivanja i
  JOIN uredaji u ON u.id = i.uredaj_id
  LEFT JOIN klijenti k ON k.id = u.klijent_id
  WHERE u.aktivan = 1 AND i.sljedeci_datum IS NOT NULL
    AND i.id = (SELECT i2.id FROM ispitivanja i2
                WHERE i2.uredaj_id = i.uredaj_id AND COALESCE(i2.vrsta, '') = COALESCE(i.vrsta, '')
                  AND i2.sljedeci_datum IS NOT NULL
                ORDER BY i2.datum DESC, i2.id DESC LIMIT 1)
) WHERE 1 = 1
"""


def rokovi(klijent_id=None, uredaj_id=None):
    """Aktualni rokovi: zadnji upisani 'sljedeći datum' po uređaju (održavanje)
    odnosno po uređaju i vrsti ispitivanja."""
    sql, args = RokoviSQL, []
    if klijent_id:
        sql += " AND klijent_id = ?"
        args.append(klijent_id)
    if uredaj_id:
        sql += " AND uredaj_id = ?"
        args.append(uredaj_id)
    sql += " ORDER BY sljedeci_datum"
    out = []
    for r in q(sql, args):
        d = dict(r)
        d["status"], d["dani"] = status_roka(d["sljedeci_datum"])
        out.append(d)
    return out


def sazetak_po_uredaju(lista):
    """Za svaki uređaj najbliži rok održavanja i ispitivanja."""
    s = {}
    for r in lista:
        e = s.setdefault(r["uredaj_id"], {"odrzavanje": None, "ispitivanje": None})
        cur = e[r["tip"]]
        if cur is None or r["dani"] < cur["dani"]:
            e[r["tip"]] = r
    return s


def sljedeci_broj_zapisnika():
    god = date.today().year
    n = q("SELECT COUNT(*) AS n FROM ispitivanja WHERE broj_zapisnika LIKE ?", (f"PP-{god}-%",), one=True)["n"]
    return f"PP-{god}-{n + 1:04d}"


# ---------------------------------------------------------------- Jinja

@app.template_filter("dt")
def fmt_date(s):
    d = parse_date(s) if isinstance(s, str) else s
    return d.strftime(t("%d.%m.%Y", "%d.%m.%Y.")) if d else ""


@app.template_filter("dtv")
def fmt_datum_vrijeme(s):
    try:
        return datetime.fromisoformat(s).strftime(t("%d.%m.%Y %H:%M", "%d.%m.%Y. %H:%M")) if s else ""
    except ValueError:
        return s


# Vrijednosti koje je aplikacija sama upisivala u bazu na hrvatskom (stari zapisi) i oznake rezultata
# ispitivanja (spremaju se kao ključevi) – prikazuju se na njemačkom.
PRIKAZ_DE = {
    "Zadovoljava": "Entspricht",
    "Zadovoljava uz napomene": "Entspricht mit Anmerkungen",
    "Ne zadovoljava": "Entspricht nicht",
    "N/P": "n. z.",
    "Redovno održavanje": "Regelwartung",
    "Izvanredno održavanje": "Außerplanmäßige Wartung",
    "Popravak / kvar": "Reparatur / Störung",
    "Servis": "Service",
    "Pregled": "Inspektion",
    "Eksterni servis": "Externer Service",
    "Ispitivanje": "Prüfung",
    "Početno stanje (upisano ručno)": "Anfangsstand (manuell eingetragen)",
    "Početno stanje": "Anfangsbestand",
}
REZULTATI = ["Zadovoljava", "Zadovoljava uz napomene", "Ne zadovoljava"]


PRIKAZ_HR = {de: hr for hr, de in PRIKAZ_DE.items()}


@app.template_filter("prikaz")
@app.template_filter("de")
def prikaz_de(v):
    if not isinstance(v, str):
        return v
    return PRIKAZ_HR.get(v, v) if jezik() == "hr" else PRIKAZ_DE.get(v, v)


@app.template_filter("eur")
def fmt_eur(v):
    if v is None:
        return ""
    return f"{v:,.2f}".replace(",", " ").replace(".", ",").replace(" ", ".") + " €"


@app.template_filter("kol")
def fmt_kolicina(v):
    if v is None:
        return ""
    return f"{v:g}".replace(".", ",")


@app.template_filter("dani_tekst")
def dani_tekst(dani):
    if dani is None:
        return ""
    if dani < 0:
        return t(f"seit {-dani} Tg. überfällig", f"istekao prije {-dani} d.")
    if dani == 0:
        return t("heute fällig", "ističe danas")
    return t(f"in {dani} Tg.", f"za {dani} d.")


@app.context_processor
def globalno():
    try:
        sve = rokovi()
        n_ist = sum(1 for r in sve if r["status"] == "istekao")
        n_usk = sum(1 for r in sve if r["status"] == "uskoro")
    except sqlite3.Error:
        n_ist = n_usk = 0
    try:
        n_malo = q(f"SELECT COUNT(*) AS n FROM inventar WHERE {MALO_ZALIHA}", one=True)["n"]
        n_servis = q("SELECT COUNT(*) AS n FROM eksterni_servisi WHERE datum_povratka IS NULL", one=True)["n"]
    except sqlite3.Error:
        n_malo = n_servis = 0
    try:
        izbornici = q("SELECT * FROM izbornici ORDER BY poredak, naziv")
        zt = q("SELECT COUNT(*) AS n, COALESCE(SUM(prioritet), 0) AS p FROM zahtjevi WHERE izvrsen = 0", one=True)
    except sqlite3.Error:
        izbornici, zt = [], {"n": 0, "p": 0}
    return {"n_istekli": n_ist, "n_uskoro": n_usk, "n_malo_zaliha": n_malo, "n_na_servisu": n_servis,
            "rezultati": REZULTATI, "jezik": jezik(),
            "vlastiti_izbornici": izbornici, "n_zahtjeva": zt["n"], "n_prioritetnih": zt["p"],
            "firma": postavke(),
            "danas": date.today().isoformat(), "dani_upozorenja": dani_upozorenja()}


# ---------------------------------------------------------------- početna i rokovi

@app.route("/")
def pocetna():
    sve = rokovi()
    hitno = [r for r in sve if r["status"] in ("istekao", "uskoro")]
    bez_evidencije = q("""
        SELECT u.*, k.naziv AS klijent FROM uredaji u LEFT JOIN klijenti k ON k.id = u.klijent_id
        WHERE u.aktivan = 1
          AND NOT EXISTS (SELECT 1 FROM odrzavanja o WHERE o.uredaj_id = u.id AND o.sljedeci_datum IS NOT NULL)
          AND NOT EXISTS (SELECT 1 FROM ispitivanja i WHERE i.uredaj_id = u.id AND i.sljedeci_datum IS NOT NULL)
        ORDER BY u.naziv""")
    zadnje = q("""
        SELECT * FROM (
          SELECT 'odrzavanje' AS tip, o.id, o.datum, o.vrsta, u.id AS uredaj_id, u.naziv AS uredaj, k.naziv AS klijent
          FROM odrzavanja o JOIN uredaji u ON u.id = o.uredaj_id LEFT JOIN klijenti k ON k.id = u.klijent_id
          UNION ALL
          SELECT 'ispitivanje', i.id, i.datum, i.vrsta, u.id, u.naziv, k.naziv
          FROM ispitivanja i JOIN uredaji u ON u.id = i.uredaj_id LEFT JOIN klijenti k ON k.id = u.klijent_id
        ) ORDER BY datum DESC, id DESC LIMIT 10""")
    stat = {
        "klijenti": q("SELECT COUNT(*) AS n FROM klijenti", one=True)["n"],
        "uredaji": q("SELECT COUNT(*) AS n FROM uredaji WHERE aktivan = 1", one=True)["n"],
    }
    return render_template("pocetna.html", hitno=hitno, bez_evidencije=bez_evidencije,
                           zadnje=zadnje, stat=stat)


@app.route("/rokovi")
def rokovi_view():
    status = request.args.get("status", "hitno")
    tip = request.args.get("tip", "")
    klijent_id = request.args.get("klijent_id", type=int)
    trazi = (request.args.get("q") or "").strip().lower()
    lista = rokovi(klijent_id=klijent_id)
    if status == "hitno":
        lista = [r for r in lista if r["status"] in ("istekao", "uskoro")]
    elif status in ("istekao", "uskoro", "ok"):
        lista = [r for r in lista if r["status"] == status]
    if tip:
        lista = [r for r in lista if r["tip"] == tip]
    if trazi:
        lista = [r for r in lista if trazi in " ".join(
            str(r[k] or "") for k in ("uredaj", "klijent", "serijski_broj", "vrsta", "lokacija")).lower()]
    klijenti = q("SELECT id, naziv FROM klijenti ORDER BY naziv")
    return render_template("rokovi.html", lista=lista, status=status, tip=tip,
                           klijent_id=klijent_id, trazi=trazi, klijenti=klijenti)


@app.route("/api/obavijesti")
def api_obavijesti():
    lista = [r for r in rokovi() if r["status"] in ("istekao", "uskoro")]
    return jsonify({
        "istekli": sum(1 for r in lista if r["status"] == "istekao"),
        "uskoro": sum(1 for r in lista if r["status"] == "uskoro"),
        "stavke": [{"tip": r["tip"], "uredaj": r["uredaj"], "klijent": r["klijent"],
                    "sljedeci_datum": r["sljedeci_datum"], "dani": r["dani"], "status": r["status"]}
                   for r in lista],
    })


# ---------------------------------------------------------------- klijenti

KLIJENT_POLJA = ["naziv", "oib", "adresa", "grad", "kontakt_osoba", "telefon", "email", "napomena"]


@app.route("/klijenti")
def klijenti():
    trazi = (request.args.get("q") or "").strip()
    sql = """SELECT k.*, (SELECT COUNT(*) FROM uredaji u WHERE u.klijent_id = k.id) AS br_uredaja
             FROM klijenti k"""
    args = ()
    if trazi:
        sql += " WHERE k.naziv LIKE ? OR k.oib LIKE ? OR k.grad LIKE ? OR k.kontakt_osoba LIKE ?"
        args = (f"%{trazi}%",) * 4
    lista = q(sql + " ORDER BY k.naziv", args)
    po_klijentu = {}
    for r in rokovi():
        if r["klijent_id"] and r["status"] in ("istekao", "uskoro"):
            e = po_klijentu.setdefault(r["klijent_id"], {"istekao": 0, "uskoro": 0})
            e[r["status"]] += 1
    return render_template("klijenti.html", lista=lista, trazi=trazi, po_klijentu=po_klijentu)


@app.route("/klijenti/novi", methods=["GET", "POST"])
@app.route("/klijenti/<int:kid>/uredi", methods=["GET", "POST"])
def klijent_form(kid=None):
    k = get_or_404("klijenti", kid) if kid else None
    if request.method == "POST":
        data = form_data(KLIJENT_POLJA)
        if not data["naziv"]:
            flash(t("Der Kundenname ist erforderlich.", "Naziv klijenta je obavezan."), "greska")
            return render_template("klijent_form.html", k=data, kid=kid)
        if kid:
            update("klijenti", kid, data)
        else:
            kid = insert("klijenti", data)
        flash(t("Kunde gespeichert.", "Klijent spremljen."), "ok")
        return redirect(url_for("klijent_detalj", kid=kid))
    return render_template("klijent_form.html", k=k or {}, kid=kid)


@app.route("/klijenti/<int:kid>")
def klijent_detalj(kid):
    k = get_or_404("klijenti", kid)
    vrsta = request.args.get("vrsta")
    svi = q("SELECT * FROM uredaji WHERE klijent_id = ? ORDER BY aktivan DESC, naziv", (kid,))
    po_vrsti = {}
    for u in svi:
        po_vrsti[u["vrsta"] or ""] = po_vrsti.get(u["vrsta"] or "", 0) + 1
    uredaji = [u for u in svi if vrsta is None or (u["vrsta"] or "") == vrsta]
    saz = sazetak_po_uredaju(rokovi(klijent_id=kid))
    return render_template("klijent_detalj.html", k=k, uredaji=uredaji, saz=saz, vrsta=vrsta,
                           br_svih=len(svi), po_vrsti=sorted(po_vrsti.items(), key=lambda v: (v[0] == "", v[0].lower())))


@app.route("/klijenti/<int:kid>/obrisi", methods=["POST"])
def klijent_obrisi(kid):
    get_or_404("klijenti", kid)
    n = q("SELECT COUNT(*) AS n FROM uredaji WHERE klijent_id = ?", (kid,), one=True)["n"]
    if n:
        flash(t(f"Der Kunde hat {n} Maschinen – bitte zuerst die Maschinen löschen oder verschieben.", f"Klijent ima {n} uređaja – najprije obrišite ili premjestite uređaje."), "greska")
        return redirect(url_for("klijent_detalj", kid=kid))
    x("DELETE FROM klijenti WHERE id = ?", (kid,))
    flash(t("Kunde gelöscht.", "Klijent obrisan."), "ok")
    return redirect(url_for("klijenti"))


@app.route("/klijenti/<int:kid>/izvjestaj")
def klijent_izvjestaj(kid):
    k = get_or_404("klijenti", kid)
    uredaji = q("""SELECT u.*,
        (SELECT MAX(datum) FROM odrzavanja o WHERE o.uredaj_id = u.id) AS zadnje_odrz,
        (SELECT MAX(datum) FROM ispitivanja i WHERE i.uredaj_id = u.id) AS zadnje_isp
        FROM uredaji u WHERE u.klijent_id = ? AND u.aktivan = 1 ORDER BY u.naziv""", (kid,))
    saz = sazetak_po_uredaju(rokovi(klijent_id=kid))
    return render_template("ispis_klijent.html", k=k, uredaji=uredaji, saz=saz)


# ---------------------------------------------------------------- uređaji

UREDAJ_POLJA = ["klijent_id", "naziv", "vrsta", "proizvodjac", "model", "serijski_broj",
                "inventarni_broj", "godina_proizvodnje", "lokacija", "interval_odrzavanja",
                "interval_ispitivanja", "napomena", "aktivan"]
UREDAJ_INT = ("klijent_id", "godina_proizvodnje", "interval_odrzavanja", "interval_ispitivanja")


@app.route("/uredaji")
def uredaji():
    trazi = (request.args.get("q") or "").strip()
    klijent_id = request.args.get("klijent_id", type=int)
    sql = """SELECT u.*, k.naziv AS klijent FROM uredaji u
             LEFT JOIN klijenti k ON k.id = u.klijent_id WHERE 1 = 1"""
    args = []
    if trazi:
        sql += """ AND (u.naziv LIKE ? OR u.serijski_broj LIKE ? OR u.inventarni_broj LIKE ?
                   OR u.proizvodjac LIKE ? OR u.lokacija LIKE ? OR k.naziv LIKE ?)"""
        args += [f"%{trazi}%"] * 6
    if klijent_id:
        sql += " AND u.klijent_id = ?"
        args.append(klijent_id)
    vrsta = request.args.get("vrsta")
    if vrsta is not None and vrsta != "*":
        sql += " AND COALESCE(u.vrsta, '') = ?"
        args.append(vrsta)
    lokacija = request.args.get("lokacija")
    if lokacija is not None and lokacija != "*":
        sql += " AND COALESCE(TRIM(u.lokacija), '') = ?"
        args.append(lokacija)
    if request.args.get("servis"):
        sql += " AND u.id IN (SELECT uredaj_id FROM eksterni_servisi WHERE datum_povratka IS NULL)"
    lista = q(sql + " ORDER BY u.aktivan DESC, k.naziv, u.naziv", args)
    saz = sazetak_po_uredaju(rokovi())
    klijenti = q("SELECT id, naziv FROM klijenti ORDER BY naziv")
    lokacije = [r["l"] for r in q("""SELECT DISTINCT TRIM(lokacija) AS l FROM uredaji
                                     WHERE TRIM(COALESCE(lokacija, '')) <> '' ORDER BY 1 COLLATE NOCASE""")]
    return render_template("uredaji.html", lista=lista, saz=saz, trazi=trazi,
                           vrsta="*" if vrsta is None else vrsta,
                           lokacija="*" if lokacija is None else lokacija, lokacije=lokacije,
                           klijent_id=klijent_id, klijenti=klijenti, na_servisu=na_servisu())


@app.template_global()
def vrste_uredaja():
    """Sve vrste: vlastiti popis + vrste već upisane na uređajima."""
    return [r["naziv"] for r in q("""
        SELECT naziv FROM vrste_uredaja
        UNION SELECT TRIM(vrsta) FROM uredaji WHERE TRIM(COALESCE(vrsta, '')) <> ''
        ORDER BY 1 COLLATE NOCASE""")]


def vrsta_iz_forme(data):
    """Odabir „+ Dodaj novu vrstu…” sprema novu vrstu u popis."""
    if data.get("vrsta") == "__nova__":
        data["vrsta"] = (request.form.get("nova_vrsta") or "").strip() or None
    if data.get("vrsta"):
        x("INSERT OR IGNORE INTO vrste_uredaja (naziv) VALUES (?)", (data["vrsta"],))


@app.route("/uredaji/vrste", methods=["GET", "POST"])
def uredaj_vrste():
    if request.method == "POST":
        staro = (request.form.get("staro") or "").strip()
        novo = (request.form.get("novo") or "").strip()
        if request.form.get("akcija") == "obrisi":
            x("DELETE FROM vrste_uredaja WHERE naziv = ?", (staro,))
            n = q("SELECT COUNT(*) AS n FROM uredaji WHERE vrsta = ?", (staro,), one=True)["n"]
            flash(t(f"Kategorie „{staro}“ aus der Liste entfernt." +
                  (f" {n} Maschinen haben diese Kategorie noch, daher wird sie weiter angezeigt." if n else ""), f"Vrsta „{staro}” uklonjena iz popisa." +
                  (f" {n} uređaja i dalje ima tu vrstu pa se ona još prikazuje." if n else "")), "ok")
        elif novo:
            x("INSERT OR IGNORE INTO vrste_uredaja (naziv) VALUES (?)", (novo,))
            if staro and staro != novo:
                x("DELETE FROM vrste_uredaja WHERE naziv = ?", (staro,))
                x("UPDATE uredaji SET vrsta = ? WHERE vrsta = ?", (novo, staro))
            flash(t("Kategorie gespeichert.", "Vrsta spremljena."), "ok")
        return redirect(url_for("uredaj_vrste"))
    broj = {r["vrsta"]: r["n"] for r in q("SELECT vrsta, COUNT(*) AS n FROM uredaji GROUP BY vrsta")}
    return render_template("uredaj_vrste.html", vrste=vrste_uredaja(), broj=broj)


@app.route("/uredaji/novi", methods=["GET", "POST"])
@app.route("/uredaji/<int:uid>/uredi", methods=["GET", "POST"])
def uredaj_form(uid=None):
    u = get_or_404("uredaji", uid) if uid else None
    klijenti = q("SELECT id, naziv FROM klijenti ORDER BY naziv")
    predlosci = q("SELECT id, naziv FROM predlosci ORDER BY naziv")
    if request.method == "POST":
        data = form_data(UREDAJ_POLJA, ints=UREDAJ_INT, checkboxes=("aktivan",))
        vrsta_iz_forme(data)
        if not data["naziv"]:
            flash(t("Die Bezeichnung der Maschine ist erforderlich.", "Naziv uređaja je obavezan."), "greska")
            return render_template("uredaj_form.html", u=data, uid=uid, klijenti=klijenti,
                                   predlosci=predlosci, pocetno=request.form)
        # početno stanje (samo kod novog uređaja): ručno upisani zadnji i sljedeći datumi
        pocetni = []
        if not uid:
            for tip in ("odrz", "isp"):
                zadnje = (request.form.get(f"{tip}_zadnje") or "").strip()
                sljedece = (request.form.get(f"{tip}_sljedece") or "").strip() or None
                if zadnje or sljedece:
                    zapis = {"datum": zadnje or date.today().isoformat(), "sljedeci_datum": sljedece}
                    greska = provjeri_datume(zapis)
                    if greska:
                        naziv = t("Wartung", "održavanje") if tip == "odrz" else t("Prüfung", "ispitivanje")
                        flash(t(f"Anfangsstand {naziv}: {greska}", f"Početno {naziv}: {greska}"), "greska")
                        return render_template("uredaj_form.html", u=data, uid=uid, klijenti=klijenti,
                                               predlosci=predlosci, pocetno=request.form)
                    pocetni.append((tip, zapis))
        if uid:
            update("uredaji", uid, data)
        else:
            uid = insert("uredaji", data)
            for tip, zapis in pocetni:
                if tip == "odrz":
                    insert("odrzavanja", {"uredaj_id": uid, "vrsta": t("Regelwartung", "Redovno održavanje"),
                                          "opis": t("Anfangsstand (manuell eingetragen)", "Početno stanje (upisano ručno)"), **zapis})
                else:
                    pid = request.form.get("isp_predlozak_id", type=int)
                    p = q("SELECT * FROM predlosci WHERE id = ?", (pid,), one=True) if pid else None
                    insert("ispitivanja", {"uredaj_id": uid, "predlozak_id": pid,
                                           "vrsta": p["naziv"] if p else t("Prüfung", "Ispitivanje"),
                                           "napomena": t("Anfangsstand (manuell eingetragen)", "Početno stanje (upisano ručno)"), **zapis})
        flash(t("Maschine gespeichert.", "Uređaj spremljen."), "ok")
        return redirect(url_for("uredaj_detalj", uid=uid))
    if not u:
        u = {"klijent_id": request.args.get("klijent_id", type=int), "vrsta": request.args.get("vrsta"),
             "aktivan": 1}
    return render_template("uredaj_form.html", u=u, uid=uid, klijenti=klijenti,
                           predlosci=predlosci, pocetno={})


@app.route("/uredaji/<int:uid>")
def uredaj_detalj(uid):
    u = q("""SELECT u.*, k.naziv AS klijent FROM uredaji u
             LEFT JOIN klijenti k ON k.id = u.klijent_id WHERE u.id = ?""", (uid,), one=True)
    if not u:
        abort(404)
    odrz = q("SELECT * FROM odrzavanja WHERE uredaj_id = ? ORDER BY datum DESC, id DESC", (uid,))
    isp = q("SELECT * FROM ispitivanja WHERE uredaj_id = ? ORDER BY datum DESC, id DESC", (uid,))
    rk = rokovi(uredaj_id=uid)
    predlosci = q("SELECT id, naziv FROM predlosci ORDER BY naziv")
    servisi = q("SELECT * FROM eksterni_servisi WHERE uredaj_id = ? ORDER BY datum_slanja DESC, id DESC", (uid,))
    aktivni_servis = next((s for s in servisi if not s["datum_povratka"]), None)
    formulari = q("SELECT id, naziv FROM formulari ORDER BY naziv")
    zapisi = q("SELECT * FROM formular_zapisi WHERE uredaj_id = ? ORDER BY datum DESC, id DESC", (uid,))
    gotovi = q("SELECT id, naziv, izvorno_ime FROM dokumenti WHERE uredaj_id IS NULL ORDER BY naziv")
    dokumenti = q("SELECT * FROM dokumenti WHERE uredaj_id = ? ORDER BY datum DESC, id DESC", (uid,))
    zahtjevi_u = q("""SELECT * FROM zahtjevi WHERE uredaj_id = ?
                      ORDER BY izvrsen, prioritet DESC, datum_prijave DESC LIMIT 50""", (uid,))
    return render_template("uredaj_detalj.html", u=u, odrz=odrz, isp=isp, rk=rk, predlosci=predlosci,
                           servisi=servisi, aktivni_servis=aktivni_servis, formulari=formulari, zapisi=zapisi,
                           gotovi=gotovi, dokumenti=dokumenti, zahtjevi=zahtjevi_u)


@app.route("/uredaji/<int:uid>/obrisi", methods=["POST"])
def uredaj_obrisi(uid):
    u = get_or_404("uredaji", uid)
    for d in q("SELECT datoteka FROM dokumenti WHERE uredaj_id = ?", (uid,)):
        obrisi_datoteku(d["datoteka"])
    x("DELETE FROM uredaji WHERE id = ?", (uid,))
    flash(t("Maschine und alle zugehörigen Einträge gelöscht.", "Uređaj i sva njegova evidencija obrisani."), "ok")
    if u["klijent_id"]:
        return redirect(url_for("klijent_detalj", kid=u["klijent_id"]))
    return redirect(url_for("uredaji"))


def uredaj_s_klijentom(uid):
    u = q("""SELECT u.*, k.naziv AS klijent, k.adresa AS klijent_adresa, k.grad AS klijent_grad,
                    k.oib AS klijent_oib, k.kontakt_osoba AS klijent_kontakt
             FROM uredaji u LEFT JOIN klijenti k ON k.id = u.klijent_id WHERE u.id = ?""", (uid,), one=True)
    if not u:
        abort(404)
    return u


# ---------------------------------------------------------------- održavanja

ODRZ_POLJA = ["datum", "sljedeci_datum", "vrsta", "opis", "izvrsio", "trosak", "napomena"]


@app.route("/uredaji/<int:uid>/odrzavanje/novo", methods=["GET", "POST"])
@app.route("/odrzavanja/<int:oid>/uredi", methods=["GET", "POST"])
def odrzavanje_form(uid=None, oid=None):
    o = get_or_404("odrzavanja", oid) if oid else None
    uid = o["uredaj_id"] if o else uid
    u = uredaj_s_klijentom(uid)
    if request.method == "POST":
        data = form_data(ODRZ_POLJA, floats=("trosak",))
        greska = provjeri_datume(data)
        if greska:
            flash(greska, "greska")
            return render_template("odrzavanje_form.html", o=data, oid=oid, u=u)
        if oid:
            update("odrzavanja", oid, data)
        else:
            insert("odrzavanja", {"uredaj_id": uid, **data})
        flash(t("Wartung gespeichert.", "Održavanje spremljeno."), "ok")
        return redirect(url_for("uredaj_detalj", uid=uid))
    if not o:
        o = {"datum": date.today().isoformat(), "vrsta": t("Regelwartung", "Redovno održavanje")}
    return render_template("odrzavanje_form.html", o=o, oid=oid, u=u)


@app.route("/odrzavanja/<int:oid>/obrisi", methods=["POST"])
def odrzavanje_obrisi(oid):
    o = get_or_404("odrzavanja", oid)
    x("DELETE FROM odrzavanja WHERE id = ?", (oid,))
    flash(t("Wartungseintrag gelöscht.", "Zapis o održavanju obrisan."), "ok")
    return redirect(url_for("uredaj_detalj", uid=o["uredaj_id"]))


@app.route("/odrzavanja/<int:oid>/ispis")
def odrzavanje_ispis(oid):
    o = get_or_404("odrzavanja", oid)
    return render_template("ispis_odrzavanje.html", o=o, u=uredaj_s_klijentom(o["uredaj_id"]))


# ---------------------------------------------------------------- ispitivanja

ISP_POLJA = ["predlozak_id", "broj_zapisnika", "vrsta", "datum", "sljedeci_datum",
             "ispitivac", "rezultat", "napomena"]


def stavke_iz_forme():
    nazivi = request.form.getlist("stavka_naziv")
    ocjene = request.form.getlist("stavka_ocjena")
    vrijednosti = request.form.getlist("stavka_vrijednost")
    out = []
    for i, n in enumerate(nazivi):
        n = n.strip()
        if n:
            out.append({"naziv": n,
                        "ocjena": ocjene[i] if i < len(ocjene) else "",
                        "vrijednost": (vrijednosti[i] if i < len(vrijednosti) else "").strip()})
    return out


@app.route("/uredaji/<int:uid>/ispitivanje/novo", methods=["GET", "POST"])
@app.route("/ispitivanja/<int:iid>/uredi", methods=["GET", "POST"])
def ispitivanje_form(uid=None, iid=None):
    i = get_or_404("ispitivanja", iid) if iid else None
    uid = i["uredaj_id"] if i else uid
    u = uredaj_s_klijentom(uid)
    predlosci = q("SELECT * FROM predlosci ORDER BY naziv")
    if request.method == "POST":
        data = form_data(ISP_POLJA, ints=("predlozak_id",))
        data["stavke_json"] = json.dumps(stavke_iz_forme(), ensure_ascii=False)
        greska = provjeri_datume(data)
        if greska:
            flash(greska, "greska")
            return render_template("ispitivanje_form.html", i=data, iid=iid, u=u, predlosci=predlosci,
                                   stavke=json.loads(data["stavke_json"]), interval=None)
        if iid:
            update("ispitivanja", iid, data)
        else:
            iid = insert("ispitivanja", {"uredaj_id": uid, **data})
        flash(t("Prüfung gespeichert.", "Ispitivanje spremljeno."), "ok")
        return redirect(url_for("ispitivanje_zapisnik", iid=iid))

    if i:
        i = dict(i)
        stavke = json.loads(i["stavke_json"] or "[]")
        p = q("SELECT * FROM predlosci WHERE id = ?", (i["predlozak_id"],), one=True) if i["predlozak_id"] else None
    else:
        pid = request.args.get("predlozak_id", type=int)
        vrsta = request.args.get("vrsta")
        p = None
        if pid:
            p = q("SELECT * FROM predlosci WHERE id = ?", (pid,), one=True)
        elif vrsta:
            p = q("SELECT * FROM predlosci WHERE naziv = ?", (vrsta,), one=True)
        stavke = [{"naziv": s.strip(), "ocjena": "", "vrijednost": ""}
                  for s in (p["stavke"] or "").splitlines() if s.strip()] if p else []
        i = {"predlozak_id": p["id"] if p else None, "vrsta": p["naziv"] if p else (vrsta or ""),
             "datum": date.today().isoformat(), "broj_zapisnika": sljedeci_broj_zapisnika(),
             "rezultat": "Zadovoljava"}
    interval = u["interval_ispitivanja"] or (p["interval_mj"] if p else None)
    return render_template("ispitivanje_form.html", i=i, iid=iid, u=u, predlosci=predlosci,
                           stavke=stavke, interval=interval)


@app.route("/ispitivanja/<int:iid>")
def ispitivanje_zapisnik(iid):
    i = get_or_404("ispitivanja", iid)
    stavke = json.loads(i["stavke_json"] or "[]")
    return render_template("ispis_ispitivanje.html", i=i, u=uredaj_s_klijentom(i["uredaj_id"]),
                           stavke=stavke, prazan=False)


@app.route("/ispitivanja/<int:iid>/obrisi", methods=["POST"])
def ispitivanje_obrisi(iid):
    i = get_or_404("ispitivanja", iid)
    x("DELETE FROM ispitivanja WHERE id = ?", (iid,))
    flash(t("Prüfung gelöscht.", "Ispitivanje obrisano."), "ok")
    return redirect(url_for("uredaj_detalj", uid=i["uredaj_id"]))


# ---------------------------------------------------------------- obrasci (predlošci ispitivanja)

@app.route("/obrasci")
def obrasci():
    lista = q("""SELECT p.*, (SELECT COUNT(*) FROM ispitivanja i WHERE i.predlozak_id = p.id) AS br_isp
                 FROM predlosci p ORDER BY p.naziv""")
    return render_template("obrasci.html", lista=lista)


@app.route("/obrasci/novi", methods=["GET", "POST"])
@app.route("/obrasci/<int:pid>/uredi", methods=["GET", "POST"])
def obrazac_form(pid=None):
    p = get_or_404("predlosci", pid) if pid else None
    if request.method == "POST":
        data = form_data(["naziv", "opis", "stavke", "interval_mj"], ints=("interval_mj",))
        if not data["naziv"]:
            flash(t("Der Name der Vorlage ist erforderlich.", "Naziv obrasca je obavezan."), "greska")
            return render_template("obrazac_form.html", p=data, pid=pid)
        if pid:
            update("predlosci", pid, data)
        else:
            insert("predlosci", data)
        flash(t("Vorlage gespeichert.", "Obrazac spremljen."), "ok")
        return redirect(url_for("obrasci"))
    return render_template("obrazac_form.html", p=p or {}, pid=pid)


@app.route("/obrasci/<int:pid>/obrisi", methods=["POST"])
def obrazac_obrisi(pid):
    get_or_404("predlosci", pid)
    x("DELETE FROM predlosci WHERE id = ?", (pid,))
    flash(t("Vorlage gelöscht (vorhandene Protokolle bleiben erhalten).", "Obrazac obrisan (postojeći zapisnici su sačuvani)."), "ok")
    return redirect(url_for("obrasci"))


@app.route("/obrasci/<int:pid>/prazan")
def obrazac_prazan(pid):
    """Prazan obrazac za ispis i ručno popunjavanje na terenu."""
    p = get_or_404("predlosci", pid)
    uid = request.args.get("uredaj_id", type=int)
    u = uredaj_s_klijentom(uid) if uid else {}
    stavke = [{"naziv": s.strip(), "ocjena": "", "vrijednost": ""}
              for s in (p["stavke"] or "").splitlines() if s.strip()]
    i = {"vrsta": p["naziv"], "broj_zapisnika": "", "datum": "", "sljedeci_datum": "",
         "ispitivac": "", "rezultat": "", "napomena": ""}
    return render_template("ispis_ispitivanje.html", i=i, u=u, stavke=stavke, prazan=True)


# ---------------------------------------------------------------- vlastiti formulari

FORMULAR_TIPOVI = [
    ("tekst", "Text (kurz)"),
    ("tekst_dugi", "Text (lang)"),
    ("broj", "Zahl"),
    ("datum", "Datum"),
    ("da_ne", "Ja / Nein"),
    ("izbor", "Auswahl (vorgegebene Antworten)"),
    ("naslov", "Abschnittsüberschrift"),
]
FORMULAR_TIPOVI_HR = [
    ("tekst", "Tekst (kratki)"),
    ("tekst_dugi", "Tekst (dugi)"),
    ("broj", "Broj"),
    ("datum", "Datum"),
    ("da_ne", "Da / Ne"),
    ("izbor", "Izbor (ponuđeni odgovori)"),
    ("naslov", "Naslov odjeljka"),
]


def tipovi_polja():
    return FORMULAR_TIPOVI_HR if jezik() == "hr" else FORMULAR_TIPOVI


def polja_iz_forme():
    """Definicija polja formulara iz graditelja (naziv, tip, opcije odvojene s ;)."""
    nazivi = request.form.getlist("polje_naziv")
    tipovi = request.form.getlist("polje_tip")
    opcije = request.form.getlist("polje_opcije")
    dozvoljeni = dict(FORMULAR_TIPOVI)
    out = []
    for i, n in enumerate(nazivi):
        n = n.strip()
        if not n:
            continue
        tip = tipovi[i] if i < len(tipovi) and tipovi[i] in dozvoljeni else "tekst"
        opc = [o.strip() for o in (opcije[i] if i < len(opcije) else "").split(";") if o.strip()]
        out.append({"naziv": n, "tip": tip, "opcije": opc if tip == "izbor" else []})
    return out


def vrijednosti_iz_forme(polja):
    out = []
    for i, p in enumerate(polja):
        v = "" if p["tip"] == "naslov" else (request.form.get(f"f_{i}") or "").strip()
        out.append({**p, "vrijednost": v})
    return out


@app.route("/formulari")
def formulari():
    lista = q("""SELECT f.*, (SELECT COUNT(*) FROM formular_zapisi z WHERE z.formular_id = f.id) AS br_zapisa
                 FROM formulari f ORDER BY f.naziv""")
    fid = request.args.get("formular_id", type=int)
    sql = """SELECT z.*, u.naziv AS uredaj, k.naziv AS klijent FROM formular_zapisi z
             LEFT JOIN uredaji u ON u.id = z.uredaj_id LEFT JOIN klijenti k ON k.id = u.klijent_id"""
    args = ()
    if fid:
        sql += " WHERE z.formular_id = ?"
        args = (fid,)
    zapisi = q(sql + " ORDER BY z.datum DESC, z.id DESC LIMIT 200", args)
    polja = {f["id"]: json.loads(f["polja_json"] or "[]") for f in lista}
    gotovi = q("SELECT * FROM dokumenti WHERE uredaj_id IS NULL ORDER BY naziv")
    izbornici = {i["id"]: i["naziv"] for i in q("SELECT id, naziv FROM izbornici")}
    return render_template("formulari.html", lista=lista, polja=polja, zapisi=zapisi, fid=fid,
                           tipovi=dict(tipovi_polja()), gotovi=gotovi, izbornici=izbornici)


@app.route("/formulari/novi", methods=["GET", "POST"])
@app.route("/formulari/<int:fid>/uredi", methods=["GET", "POST"])
def formular_form(fid=None):
    f = get_or_404("formulari", fid) if fid else None
    izbornici = q("SELECT id, naziv FROM izbornici ORDER BY poredak, naziv")
    if request.method == "POST":
        data = form_data(["naziv", "opis", "izbornik_id"], ints=("izbornik_id",))
        polja = polja_iz_forme()
        data["polja_json"] = json.dumps(polja, ensure_ascii=False)
        if not data["naziv"] or not polja:
            flash(t("Name des Formulars und mindestens ein Feld sind erforderlich.", "Naziv formulara i barem jedno polje su obavezni."), "greska")
            return render_template("formular_form.html", f=data, fid=fid, polja=polja, tipovi=tipovi_polja(),
                                   izbornici=izbornici)
        if fid:
            update("formulari", fid, data)
        else:
            insert("formulari", data)
        flash(t("Formular gespeichert.", "Formular spremljen."), "ok")
        return redirect(natrag_na_izbornik(data["izbornik_id"]))
    polja = json.loads(f["polja_json"] or "[]") if f else [{"naziv": "", "tip": "tekst", "opcije": []}]
    if not f:
        f = {"izbornik_id": request.args.get("izbornik_id", type=int)}
    return render_template("formular_form.html", f=f, fid=fid, polja=polja, tipovi=tipovi_polja(),
                           izbornici=izbornici)


@app.route("/formulari/<int:fid>/obrisi", methods=["POST"])
def formular_obrisi(fid):
    get_or_404("formulari", fid)
    x("DELETE FROM formulari WHERE id = ?", (fid,))
    flash(t("Formular gelöscht (ausgefüllte Einträge bleiben erhalten).", "Formular obrisan (popunjeni zapisi su sačuvani)."), "ok")
    return redirect(url_for("formulari"))


@app.route("/formulari/<int:fid>/prazan")
def formular_prazan(fid):
    """Prazan formular za ispis i ručno popunjavanje."""
    f = get_or_404("formulari", fid)
    uid = request.args.get("uredaj_id", type=int)
    z = {"naziv": f["naziv"], "datum": "", "popunio": "", "napomena": ""}
    return render_template("ispis_formular.html", z=z, u=uredaj_s_klijentom(uid) if uid else None,
                           polja=json.loads(f["polja_json"] or "[]"), prazan=True)


@app.route("/formulari/<int:fid>/popuni", methods=["GET", "POST"])
@app.route("/formulari/zapis/<int:zid>/uredi", methods=["GET", "POST"])
def formular_popuni(fid=None, zid=None):
    z = get_or_404("formular_zapisi", zid) if zid else None
    if z:
        polja = json.loads(z["polja_json"] or "[]")
        naziv = z["naziv"]
    else:
        f = get_or_404("formulari", fid)
        polja = json.loads(f["polja_json"] or "[]")
        naziv = f["naziv"]
    uredaji_sve = q("""SELECT u.id, u.naziv, u.serijski_broj, k.naziv AS klijent FROM uredaji u
                       LEFT JOIN klijenti k ON k.id = u.klijent_id ORDER BY k.naziv, u.naziv""")
    if request.method == "POST":
        data = form_data(["uredaj_id", "datum", "popunio", "napomena"], ints=("uredaj_id",))
        vrijednosti = vrijednosti_iz_forme(polja)
        data["polja_json"] = json.dumps(vrijednosti, ensure_ascii=False)
        if not data["datum"] or not parse_date(data["datum"]):
            flash(t("Das Datum ist erforderlich.", "Datum je obavezan."), "greska")
            return render_template("formular_popuni.html", z={**data, "naziv": naziv}, zid=zid, fid=fid,
                                   polja=vrijednosti, uredaji=uredaji_sve)
        if zid:
            update("formular_zapisi", zid, data)
        else:
            zid = insert("formular_zapisi", {"formular_id": fid, "naziv": naziv, **data})
        flash(t("Formular gespeichert.", "Formular spremljen."), "ok")
        return redirect(url_for("formular_zapis", zid=zid))
    if not z:
        z = {"naziv": naziv, "datum": date.today().isoformat(),
             "uredaj_id": request.args.get("uredaj_id", type=int)}
    return render_template("formular_popuni.html", z=z, zid=zid, fid=fid, polja=polja, uredaji=uredaji_sve)


@app.route("/formulari/zapis/<int:zid>")
def formular_zapis(zid):
    z = get_or_404("formular_zapisi", zid)
    u = uredaj_s_klijentom(z["uredaj_id"]) if z["uredaj_id"] else None
    return render_template("ispis_formular.html", z=z, u=u, polja=json.loads(z["polja_json"] or "[]"),
                           prazan=False)


@app.route("/formulari/zapis/<int:zid>/obrisi", methods=["POST"])
def formular_zapis_obrisi(zid):
    z = get_or_404("formular_zapisi", zid)
    x("DELETE FROM formular_zapisi WHERE id = ?", (zid,))
    flash(t("Ausgefülltes Formular gelöscht.", "Popunjeni formular obrisan."), "ok")
    if z["uredaj_id"] and request.form.get("natrag") == "uredaj":
        return redirect(url_for("uredaj_detalj", uid=z["uredaj_id"]))
    return redirect(url_for("formulari"))


# ---------------------------------------------------------------- gotovi dokumenti (Word, Excel, PDF…)

DOK_EKSTENZIJE = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".xlsm", ".odt", ".ods", ".rtf", ".txt",
                  ".csv", ".png", ".jpg", ".jpeg"}
PRIKAZ_U_PREGLEDNIKU = {".pdf", ".png", ".jpg", ".jpeg", ".txt"}


def ekstenzija(ime):
    return os.path.splitext(ime or "")[1].lower()


@app.template_filter("ikona")
def ikona_datoteke(ime):
    e = ekstenzija(ime)
    if e in (".doc", ".docx", ".odt", ".rtf"):
        return "📝"
    if e in (".xls", ".xlsx", ".xlsm", ".ods", ".csv"):
        return "📊"
    if e == ".pdf":
        return "📕"
    if e in (".png", ".jpg", ".jpeg"):
        return "🖼"
    return "📄"


def spremi_upload(datoteka):
    """Sprema učitanu datoteku pod jedinstvenim imenom; vraća (ime na disku, izvorno ime) ili None."""
    if not datoteka or not datoteka.filename:
        return None
    e = ekstenzija(datoteka.filename)
    if e not in DOK_EKSTENZIJE:
        return None
    os.makedirs(DOK_DIR, exist_ok=True)
    ime = uuid.uuid4().hex + e
    datoteka.save(os.path.join(DOK_DIR, ime))
    return ime, os.path.basename(datoteka.filename)


def obrisi_datoteku(ime):
    try:
        os.remove(os.path.join(DOK_DIR, ime))
    except OSError:
        pass


def otvori_na_racunalu(ime):
    """Aplikacija radi lokalno pa datoteku možemo otvoriti izravno u Wordu / Excelu."""
    if not hasattr(os, "startfile"):
        return False
    try:
        os.startfile(os.path.join(DOK_DIR, ime))
        return True
    except OSError:
        return False


def natrag_na_izbornik(izbornik_id, uid=None):
    if uid:
        return url_for("uredaj_detalj", uid=uid)
    if izbornik_id:
        return url_for("izbornik", iid=izbornik_id)
    return url_for("formulari")


@app.route("/dokumenti/novi", methods=["GET", "POST"])
@app.route("/dokumenti/<int:did>/uredi", methods=["GET", "POST"])
def dokument_form(did=None):
    d = get_or_404("dokumenti", did) if did else None
    uid = d["uredaj_id"] if d else request.values.get("uredaj_id", type=int)
    u = uredaj_s_klijentom(uid) if uid else None
    izbornici = q("SELECT id, naziv FROM izbornici ORDER BY poredak, naziv")
    if request.method == "POST":
        data = form_data(["naziv", "opis", "izbornik_id"], ints=("izbornik_id",))
        datoteka = request.files.get("datoteka")
        spremljeno = spremi_upload(datoteka)
        greska = None
        if datoteka and datoteka.filename and not spremljeno:
            greska = t("Dieser Dateityp wird nicht unterstützt (erlaubt: Word, Excel, PDF, Bilder, Text).", "Ta vrsta datoteke nije podržana (dozvoljeno: Word, Excel, PDF, slike, tekst).")
        elif not d and not spremljeno:
            greska = t("Bitte eine Datei auswählen.", "Odaberite datoteku.")
        if greska:
            flash(greska, "greska")
            return render_template("dokument_form.html", d=data, did=did, u=u, izbornici=izbornici)
        if not data["naziv"]:
            data["naziv"] = os.path.splitext(spremljeno[1] if spremljeno else d["izvorno_ime"])[0]
        if uid:
            data["izbornik_id"] = None
        if spremljeno:
            if d:
                obrisi_datoteku(d["datoteka"])
            data["datoteka"], data["izvorno_ime"] = spremljeno
        if did:
            update("dokumenti", did, data)
        else:
            insert("dokumenti", {"uredaj_id": uid, **data})
        flash(t("Dokument gespeichert.", "Dokument spremljen."), "ok")
        return redirect(natrag_na_izbornik(data["izbornik_id"], uid))
    if not d:
        d = {"izbornik_id": request.args.get("izbornik_id", type=int)}
    return render_template("dokument_form.html", d=d, did=did, u=u, izbornici=izbornici)


@app.route("/dokumenti/<int:did>/datoteka")
def dokument_datoteka(did):
    d = get_or_404("dokumenti", did)
    preuzmi = request.args.get("preuzmi") or ekstenzija(d["datoteka"]) not in PRIKAZ_U_PREGLEDNIKU
    return send_from_directory(DOK_DIR, d["datoteka"], as_attachment=bool(preuzmi),
                               download_name=d["izvorno_ime"] or d["datoteka"])


@app.route("/dokumenti/<int:did>/otvori", methods=["POST"])
def dokument_otvori(did):
    d = get_or_404("dokumenti", did)
    if otvori_na_racunalu(d["datoteka"]):
        flash(t(f"„{d['naziv']}“ wurde auf dem Computer geöffnet.", f"„{d['naziv']}” otvoren na računalu."), "ok")
    else:
        flash(t("Die Datei kann nicht direkt geöffnet werden – bitte herunterladen.", "Datoteku nije moguće otvoriti izravno – preuzmite je."), "greska")
    return redirect(request.referrer or natrag_na_izbornik(d["izbornik_id"], d["uredaj_id"]))


@app.route("/dokumenti/<int:did>/popuni", methods=["POST"])
def dokument_kopija(did):
    """Kopija gotovog formulara (predloška) za uređaj; original ostaje netaknut."""
    d = get_or_404("dokumenti", did)
    uid = request.form.get("uredaj_id", type=int)
    u = uredaj_s_klijentom(uid)
    novo = uuid.uuid4().hex + ekstenzija(d["datoteka"])
    try:
        shutil.copyfile(os.path.join(DOK_DIR, d["datoteka"]), os.path.join(DOK_DIR, novo))
    except OSError:
        flash(t("Die Vorlagendatei wurde nicht gefunden.", "Datoteka predloška nije pronađena."), "greska")
        return redirect(url_for("uredaj_detalj", uid=uid))
    osnova, e = os.path.splitext(d["izvorno_ime"] or d["datoteka"])
    insert("dokumenti", {"naziv": d["naziv"], "opis": d["opis"], "datoteka": novo, "uredaj_id": uid,
                         "izvorno_ime": f"{osnova} - {u['naziv']} {date.today().isoformat()}{e}"})
    if otvori_na_racunalu(novo):
        flash(t(f"Kopie von „{d['naziv']}“ geöffnet – ausfüllen und speichern (Strg+S).", f"Kopija „{d['naziv']}” otvorena – popunite je i spremite (Ctrl+S)."), "ok")
    else:
        flash(t(f"Kopie von „{d['naziv']}“ zur Maschine hinzugefügt.", f"Kopija „{d['naziv']}” dodana uređaju."), "ok")
    return redirect(url_for("uredaj_detalj", uid=uid))


@app.route("/dokumenti/<int:did>/obrisi", methods=["POST"])
def dokument_obrisi(did):
    d = get_or_404("dokumenti", did)
    x("DELETE FROM dokumenti WHERE id = ?", (did,))
    obrisi_datoteku(d["datoteka"])
    flash(t("Dokument gelöscht.", "Dokument obrisan."), "ok")
    return redirect(request.referrer or natrag_na_izbornik(d["izbornik_id"], d["uredaj_id"]))


@app.errorhandler(413)
def prevelika_datoteka(e):
    return render_template("greska.html", poruka=t("Die Datei ist zu groß (maximal 100 MB).", "Datoteka je prevelika (najviše 100 MB).")), 413


# ---------------------------------------------------------------- vlastiti izbornici

@app.route("/izbornici")
def izbornici():
    lista = q("""SELECT i.*,
        (SELECT COUNT(*) FROM formulari f WHERE f.izbornik_id = i.id) AS br_formulara,
        (SELECT COUNT(*) FROM dokumenti d WHERE d.izbornik_id = i.id) AS br_dokumenata
        FROM izbornici i ORDER BY i.poredak, i.naziv""")
    return render_template("izbornici.html", lista=lista)


@app.route("/izbornici/novi", methods=["GET", "POST"])
@app.route("/izbornici/<int:iid>/uredi", methods=["GET", "POST"])
def izbornik_form(iid=None):
    i = get_or_404("izbornici", iid) if iid else None
    if request.method == "POST":
        data = form_data(["naziv", "opis", "poveznica", "poredak"], ints=("poredak",))
        if not data["naziv"]:
            flash(t("Der Name des Menüs ist erforderlich.", "Naziv izbornika je obavezan."), "greska")
            return render_template("izbornik_form.html", i=data, iid=iid)
        if data["poveznica"] and "://" not in data["poveznica"]:
            data["poveznica"] = "https://" + data["poveznica"]
        data["poredak"] = data["poredak"] or 0
        if iid:
            update("izbornici", iid, data)
        else:
            iid = insert("izbornici", data)
        flash(t("Menü gespeichert – es ist in der oberen Leiste sichtbar.", "Izbornik spremljen – vidljiv je u gornjoj traci."), "ok")
        return redirect(url_for("izbornici") if data["poveznica"] else url_for("izbornik", iid=iid))
    return render_template("izbornik_form.html", i=i or {}, iid=iid)


@app.route("/izbornici/<int:iid>/obrisi", methods=["POST"])
def izbornik_obrisi(iid):
    get_or_404("izbornici", iid)
    x("UPDATE formulari SET izbornik_id = NULL WHERE izbornik_id = ?", (iid,))
    x("UPDATE dokumenti SET izbornik_id = NULL WHERE izbornik_id = ?", (iid,))
    x("DELETE FROM izbornici WHERE id = ?", (iid,))
    flash(t("Menü gelöscht (seine Formulare und Dokumente wurden nach „Formulare“ verschoben).", "Izbornik obrisan (njegovi formulari i dokumenti premješteni su u Formulare)."), "ok")
    return redirect(url_for("izbornici"))


@app.route("/izbornik/<int:iid>")
def izbornik(iid):
    i = get_or_404("izbornici", iid)
    formulari_l = q("""SELECT f.*, (SELECT COUNT(*) FROM formular_zapisi z WHERE z.formular_id = f.id) AS br_zapisa
                       FROM formulari f WHERE f.izbornik_id = ? ORDER BY f.naziv""", (iid,))
    dokumenti = q("SELECT * FROM dokumenti WHERE izbornik_id = ? AND uredaj_id IS NULL ORDER BY naziv", (iid,))
    zapisi = q("""SELECT z.*, u.naziv AS uredaj FROM formular_zapisi z
                  JOIN formulari f ON f.id = z.formular_id LEFT JOIN uredaji u ON u.id = z.uredaj_id
                  WHERE f.izbornik_id = ? ORDER BY z.datum DESC, z.id DESC LIMIT 100""", (iid,))
    return render_template("izbornik.html", i=i, formulari=formulari_l, dokumenti=dokumenti, zapisi=zapisi)


# ---------------------------------------------------------------- zahtjevi (ticket sustav)

ZAHTJEV_POLJA = ["naslov", "opis", "podnositelj", "kontakt", "lokacija", "uredaj_id"]
JAVNE_STRANICE = {"prijava", "static", "promijeni_jezik"}


@app.before_request
def samo_prijava_s_mreze():
    """S drugih računala (pokretanje s --mreza) dostupna je samo stranica za prijavu zahtjeva."""
    if request.remote_addr not in ("127.0.0.1", "::1") and request.endpoint not in JAVNE_STRANICE:
        abort(403)


def sada():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def uredaji_za_odabir():
    return q("""SELECT u.id, u.naziv, u.serijski_broj, u.lokacija, k.naziv AS klijent FROM uredaji u
                LEFT JOIN klijenti k ON k.id = u.klijent_id WHERE u.aktivan = 1 ORDER BY k.naziv, u.naziv""")


@app.route("/zahtjevi")
def zahtjevi():
    status = request.args.get("status", "otvoreni")
    prioritet = request.args.get("prioritet")
    trazi = (request.args.get("q") or "").strip()
    sql = """SELECT z.*, u.naziv AS uredaj FROM zahtjevi z
             LEFT JOIN uredaji u ON u.id = z.uredaj_id WHERE 1 = 1"""
    args = []
    if status == "otvoreni":
        sql += " AND z.izvrsen = 0"
    elif status == "izvrseni":
        sql += " AND z.izvrsen = 1"
    if prioritet:
        sql += " AND z.prioritet = 1"
    if trazi:
        sql += """ AND (z.naslov LIKE ? OR z.opis LIKE ? OR z.podnositelj LIKE ?
                   OR z.lokacija LIKE ? OR u.naziv LIKE ?)"""
        args += [f"%{trazi}%"] * 5
    sql += " ORDER BY z.izvrsen, z.prioritet DESC, " + (
        "z.datum_izvrsenja DESC" if status == "izvrseni" else "z.datum_prijave DESC")
    lista = q(sql, args)
    return render_template("zahtjevi.html", lista=lista, status=status, prioritet=prioritet, trazi=trazi)


@app.route("/zahtjevi/novi", methods=["GET", "POST"])
@app.route("/zahtjevi/<int:zid>", methods=["GET", "POST"])
def zahtjev_form(zid=None):
    z = get_or_404("zahtjevi", zid) if zid else None
    if request.method == "POST":
        data = form_data(ZAHTJEV_POLJA + ["napomena_izvrsenja", "prioritet", "izvrsen"],
                         ints=("uredaj_id",), checkboxes=("prioritet", "izvrsen"))
        if not data["naslov"]:
            flash(t("Der Titel der Anfrage ist erforderlich.", "Naslov zahtjeva je obavezan."), "greska")
            return render_template("zahtjev_form.html", z=data, zid=zid, uredaji=uredaji_za_odabir())
        if data["izvrsen"]:
            data["datum_izvrsenja"] = (z["datum_izvrsenja"] if z and z["izvrsen"] else None) or sada()
        else:
            data["datum_izvrsenja"] = None
        if zid:
            update("zahtjevi", zid, data)
        else:
            zid = insert("zahtjevi", {**data, "datum_prijave": sada()})
        flash(t("Anfrage gespeichert.", "Zahtjev spremljen."), "ok")
        return redirect(url_for("zahtjevi"))
    if not z:
        z = {"uredaj_id": request.args.get("uredaj_id", type=int)}
    return render_template("zahtjev_form.html", z=z, zid=zid, uredaji=uredaji_za_odabir())


@app.route("/zahtjevi/<int:zid>/izvrsen", methods=["POST"])
def zahtjev_izvrsen(zid):
    z = get_or_404("zahtjevi", zid)
    if z["izvrsen"]:
        x("UPDATE zahtjevi SET izvrsen = 0, datum_izvrsenja = NULL WHERE id = ?", (zid,))
        flash(t(f"Anfrage #{zid} wieder auf offen gesetzt.", f"Zahtjev #{zid} vraćen među neizvršene."), "ok")
    else:
        x("UPDATE zahtjevi SET izvrsen = 1, datum_izvrsenja = ? WHERE id = ?", (sada(), zid))
        flash(t(f"Anfrage #{zid} als erledigt markiert.", f"Zahtjev #{zid} označen kao izvršen."), "ok")
    return redirect(request.referrer or url_for("zahtjevi"))


@app.route("/zahtjevi/<int:zid>/prioritet", methods=["POST"])
def zahtjev_prioritet(zid):
    z = get_or_404("zahtjevi", zid)
    x("UPDATE zahtjevi SET prioritet = ? WHERE id = ?", (0 if z["prioritet"] else 1, zid))
    return redirect(request.referrer or url_for("zahtjevi"))


@app.route("/zahtjevi/<int:zid>/obrisi", methods=["POST"])
def zahtjev_obrisi(zid):
    get_or_404("zahtjevi", zid)
    x("DELETE FROM zahtjevi WHERE id = ?", (zid,))
    flash(t("Anfrage gelöscht.", "Zahtjev obrisan."), "ok")
    return redirect(url_for("zahtjevi"))


@app.route("/prijava", methods=["GET", "POST"])
def prijava():
    """Jednostavna stranica na kojoj korisnici prijavljuju zahtjev (kvar, popravak, nabava…)."""
    uredaji_l = uredaji_za_odabir()
    # popis već poslanih zahtjeva – samo za pregled, bez mogućnosti uređivanja
    status = request.args.get("status", "svi")
    trazi = (request.args.get("q") or "").strip()
    sql = """SELECT z.id, z.naslov, z.podnositelj, z.lokacija, z.datum_prijave, z.izvrsen, z.datum_izvrsenja,
                    z.napomena_izvrsenja, u.naziv AS uredaj
             FROM zahtjevi z LEFT JOIN uredaji u ON u.id = z.uredaj_id WHERE 1 = 1"""
    args = []
    if status == "otvoreni":
        sql += " AND z.izvrsen = 0"
    elif status == "izvrseni":
        sql += " AND z.izvrsen = 1"
    if trazi:
        sql += " AND (z.naslov LIKE ? OR z.podnositelj LIKE ? OR CAST(z.id AS TEXT) = ?)"
        args += [f"%{trazi}%", f"%{trazi}%", trazi.lstrip("#")]
    poslani = q(sql + " ORDER BY z.izvrsen, z.datum_prijave DESC LIMIT 200", args)
    pregled = {"poslani": poslani, "status": status, "trazi": trazi, "uredaji": uredaji_l}
    if request.method == "POST":
        data = form_data(ZAHTJEV_POLJA, ints=("uredaj_id",))
        if not data["naslov"] or not data["podnositelj"]:
            return render_template("prijava.html", z=data, **pregled,
                                   greska=t("Bitte Ihren Namen und eine kurze Beschreibung der Anfrage eingeben.", "Upišite svoje ime i kratki opis zahtjeva."))
        zid = insert("zahtjevi", {**data, "datum_prijave": sada()})
        return redirect(url_for("prijava", poslano=zid))
    return render_template("prijava.html", z={}, poslano=request.args.get("poslano", type=int), **pregled)


# ---------------------------------------------------------------- inventar radionice

INVENTAR_POLJA = ["naziv", "sifra", "kategorija", "jedinica", "min_kolicina", "lokacija",
                  "cijena", "dobavljac", "napomena"]
MALO_ZALIHA = "min_kolicina IS NOT NULL AND kolicina <= min_kolicina"


def upisi_promjenu(aid, vrsta, kolicina, datum, opis):
    """Ulaz / izlaz dodaje ili oduzima količinu, inventura postavlja stvarno stanje."""
    a = get_or_404("inventar", aid)
    staro = a["kolicina"] or 0
    if vrsta == "ulaz":
        novo = staro + kolicina
    elif vrsta == "izlaz":
        novo = staro - kolicina
    else:
        novo = kolicina
    x("UPDATE inventar SET kolicina = ? WHERE id = ?", (novo, aid))
    insert("inventar_promjene", {"artikl_id": aid, "datum": datum, "vrsta": vrsta,
                                 "promjena": novo - staro, "stanje": novo, "opis": opis})
    return novo


@app.route("/inventar")
def inventar():
    trazi = (request.args.get("q") or "").strip()
    kategorija = request.args.get("kategorija", "")
    sql, args = "SELECT * FROM inventar WHERE 1 = 1", []
    if trazi:
        sql += " AND (naziv LIKE ? OR sifra LIKE ? OR lokacija LIKE ? OR dobavljac LIKE ?)"
        args += [f"%{trazi}%"] * 4
    if kategorija:
        sql += " AND COALESCE(kategorija, '') = ?"
        args.append(kategorija)
    if request.args.get("malo"):
        sql += f" AND {MALO_ZALIHA}"
    lista = q(sql + " ORDER BY kategorija, naziv", args)
    kategorije = [r["kategorija"] for r in q(
        "SELECT DISTINCT kategorija FROM inventar WHERE kategorija IS NOT NULL ORDER BY kategorija")]
    vrijednost = sum((a["kolicina"] or 0) * (a["cijena"] or 0) for a in lista)
    return render_template("inventar.html", lista=lista, trazi=trazi, kategorija=kategorija,
                           kategorije=kategorije, vrijednost=vrijednost, malo=request.args.get("malo"))


@app.route("/inventar/ispis")
def inventar_ispis():
    lista = q("SELECT * FROM inventar ORDER BY kategorija, naziv")
    vrijednost = sum((a["kolicina"] or 0) * (a["cijena"] or 0) for a in lista)
    return render_template("ispis_inventar.html", lista=lista, vrijednost=vrijednost)


@app.route("/inventar/novi", methods=["GET", "POST"])
@app.route("/inventar/<int:aid>/uredi", methods=["GET", "POST"])
def inventar_form(aid=None):
    a = get_or_404("inventar", aid) if aid else None
    kategorije = [r["kategorija"] for r in q(
        "SELECT DISTINCT kategorija FROM inventar WHERE kategorija IS NOT NULL ORDER BY kategorija")]
    if request.method == "POST":
        data = form_data(INVENTAR_POLJA, floats=("min_kolicina", "cijena"))
        if not data["naziv"]:
            flash(t("Die Artikelbezeichnung ist erforderlich.", "Naziv artikla je obavezan."), "greska")
            return render_template("inventar_form.html", a=data, aid=aid, kategorije=kategorije)
        if aid:
            update("inventar", aid, data)
        else:
            aid = insert("inventar", {**data, "kolicina": 0})
            pocetno = form_data(["pocetna_kolicina"], floats=("pocetna_kolicina",))["pocetna_kolicina"]
            if pocetno:
                upisi_promjenu(aid, "inventura", pocetno, date.today().isoformat(), t("Anfangsbestand", "Početno stanje"))
        flash(t("Artikel gespeichert.", "Artikl spremljen."), "ok")
        return redirect(url_for("inventar_detalj", aid=aid))
    return render_template("inventar_form.html", a=a or {}, aid=aid, kategorije=kategorije)


@app.route("/inventar/<int:aid>")
def inventar_detalj(aid):
    a = get_or_404("inventar", aid)
    promjene = q("SELECT * FROM inventar_promjene WHERE artikl_id = ? ORDER BY datum DESC, id DESC", (aid,))
    return render_template("inventar_detalj.html", a=a, promjene=promjene)


@app.route("/inventar/<int:aid>/promjena", methods=["POST"])
def inventar_promjena(aid):
    get_or_404("inventar", aid)
    data = form_data(["vrsta", "kolicina", "datum", "opis"], floats=("kolicina",))
    if data["vrsta"] not in ("ulaz", "izlaz", "inventura") or data["kolicina"] is None \
            or (data["vrsta"] != "inventura" and data["kolicina"] <= 0) or data["kolicina"] < 0:
        flash(t("Bitte eine gültige Menge eingeben.", "Upišite ispravnu količinu."), "greska")
    else:
        novo = upisi_promjenu(aid, data["vrsta"], data["kolicina"],
                              data["datum"] if parse_date(data["datum"]) else date.today().isoformat(),
                              data["opis"])
        flash(t(f"Bestand aktualisiert: {fmt_kolicina(novo)}.", f"Stanje ažurirano: {fmt_kolicina(novo)}."), "ok")
    if request.form.get("natrag") == "lista":
        return redirect(request.referrer or url_for("inventar"))
    return redirect(url_for("inventar_detalj", aid=aid))


@app.route("/inventar/<int:aid>/obrisi", methods=["POST"])
def inventar_obrisi(aid):
    get_or_404("inventar", aid)
    x("DELETE FROM inventar WHERE id = ?", (aid,))
    flash(t("Artikel gelöscht.", "Artikl obrisan."), "ok")
    return redirect(url_for("inventar"))


# ---------------------------------------------------------------- eksterni servis

SERVIS_SLANJE = ["broj_naloga", "servis_naziv", "servis_adresa", "servis_kontakt", "servis_telefon",
                 "datum_slanja", "ocekivani_povratak", "opis_kvara", "pribor", "predao", "napomena"]
SERVIS_POVRATAK = ["datum_povratka", "izvrseni_radovi", "trosak", "broj_racuna", "preuzeo"]


def na_servisu():
    """uredaj_id -> otvoreni nalog za eksterni servis."""
    return {r["uredaj_id"]: r for r in q("SELECT * FROM eksterni_servisi WHERE datum_povratka IS NULL")}


def sljedeci_broj_naloga():
    god = date.today().year
    n = q("SELECT COUNT(*) AS n FROM eksterni_servisi WHERE broj_naloga LIKE ?", (f"SA-{god}-%",), one=True)["n"]
    return f"SA-{god}-{n + 1:04d}"


def poznati_servisi():
    return [dict(r) for r in q("""
        SELECT servis_naziv, servis_adresa, servis_kontakt, servis_telefon FROM eksterni_servisi
        WHERE id IN (SELECT MAX(id) FROM eksterni_servisi GROUP BY servis_naziv) ORDER BY servis_naziv""")]


@app.route("/servisi")
def servisi():
    sve = request.args.get("sve")
    sql = """SELECT s.*, u.naziv AS uredaj, u.serijski_broj, k.id AS klijent_id, k.naziv AS klijent
             FROM eksterni_servisi s JOIN uredaji u ON u.id = s.uredaj_id
             LEFT JOIN klijenti k ON k.id = u.klijent_id"""
    if not sve:
        sql += " WHERE s.datum_povratka IS NULL"
    lista = [dict(r) for r in q(sql + " ORDER BY s.datum_povratka IS NOT NULL, s.datum_slanja DESC")]
    for r in lista:
        r["kasni"] = (not r["datum_povratka"] and r["ocekivani_povratak"]
                      and r["ocekivani_povratak"] < date.today().isoformat())
    return render_template("servisi.html", lista=lista, sve=sve)


@app.route("/uredaji/<int:uid>/servis/novi", methods=["GET", "POST"])
@app.route("/servisi/<int:sid>/uredi", methods=["GET", "POST"])
@app.route("/servisi/<int:sid>/povratak", methods=["GET", "POST"], endpoint="servis_povratak")
def servis_form(uid=None, sid=None):
    s = get_or_404("eksterni_servisi", sid) if sid else None
    uid = s["uredaj_id"] if s else uid
    u = uredaj_s_klijentom(uid)
    povratak = request.endpoint == "servis_povratak" or bool(s and s["datum_povratka"])
    if not s and uid in na_servisu():
        flash(t("Die Maschine ist bereits beim externen Service.", "Uređaj je već na eksternom servisu."), "greska")
        return redirect(url_for("uredaj_detalj", uid=uid))
    if request.method == "POST":
        polja = SERVIS_SLANJE + (SERVIS_POVRATAK if povratak else [])
        data = form_data(polja, floats=("trosak",))
        greska = None
        if not data["servis_naziv"]:
            greska = t("Der Name des Servicebetriebs ist erforderlich.", "Naziv servisa je obavezan.")
        elif not parse_date(data["datum_slanja"]):
            greska = t("Das Versanddatum ist erforderlich.", "Datum slanja je obavezan.")
        elif povratak and not parse_date(data["datum_povratka"]):
            greska = t("Das Rückgabedatum ist erforderlich.", "Datum povratka je obavezan.")
        elif povratak and data["datum_povratka"] < data["datum_slanja"]:
            greska = t("Das Rückgabedatum darf nicht vor dem Versanddatum liegen.", "Datum povratka ne može biti prije datuma slanja.")
        if greska:
            flash(greska, "greska")
            return render_template("servis_form.html", s=data, sid=sid, u=u, povratak=povratak,
                                   servisi=poznati_servisi(), upisi_odrz=request.form.get("upisi_odrzavanje"))
        if sid:
            update("eksterni_servisi", sid, data)
        else:
            sid = insert("eksterni_servisi", {"uredaj_id": uid, **data})
        if request.endpoint == "servis_povratak" and request.form.get("upisi_odrzavanje"):
            insert("odrzavanja", {"uredaj_id": uid, "datum": data["datum_povratka"], "vrsta": t("Externer Service", "Eksterni servis"),
                                  "opis": data["izvrseni_radovi"] or data["opis_kvara"],
                                  "izvrsio": data["servis_naziv"], "trosak": data["trosak"],
                                  "napomena": t(f"Auftrag {data['broj_naloga'] or ''}", f"Nalog {data['broj_naloga'] or ''}").strip()})
        flash(t("Rückgabe vom Service erfasst.", "Povratak sa servisa evidentiran.") if povratak else t("Maschine als an externen Service gesendet markiert.", "Uređaj označen kao poslan na eksterni servis."), "ok")
        if povratak:
            return redirect(url_for("uredaj_detalj", uid=uid))
        return redirect(url_for("servis_ispis", sid=sid))
    if s:
        s = dict(s)
        if povratak and not s["datum_povratka"]:
            s["datum_povratka"] = date.today().isoformat()
    else:
        s = {"broj_naloga": sljedeci_broj_naloga(), "datum_slanja": date.today().isoformat()}
    return render_template("servis_form.html", s=s, sid=sid, u=u, povratak=povratak,
                           servisi=poznati_servisi(), upisi_odrz=True)


@app.route("/servisi/<int:sid>/ispis")
def servis_ispis(sid):
    s = get_or_404("eksterni_servisi", sid)
    return render_template("ispis_servis.html", s=s, u=uredaj_s_klijentom(s["uredaj_id"]))


@app.route("/servisi/<int:sid>/obrisi", methods=["POST"])
def servis_obrisi(sid):
    s = get_or_404("eksterni_servisi", sid)
    x("DELETE FROM eksterni_servisi WHERE id = ?", (sid,))
    flash(t("Auftrag für externen Service gelöscht.", "Nalog za eksterni servis obrisan."), "ok")
    return redirect(url_for("uredaj_detalj", uid=s["uredaj_id"]))


# ---------------------------------------------------------------- postavke

@app.route("/postavke", methods=["GET", "POST"])
def postavke_view():
    if request.method == "POST":
        for k in ZADANE_POSTAVKE:
            v = (request.form.get(k) or "").strip()
            if k == "dani_upozorenja" and not v.isdigit():
                v = "30"
            if k == "jezik" and v not in JEZICI:
                v = "de"
            x("INSERT OR REPLACE INTO postavke (kljuc, vrijednost) VALUES (?, ?)", (k, v))
        g.pop("postavke", None)
        flash(t("Einstellungen gespeichert.", "Postavke spremljene."), "ok")
        return redirect(url_for("postavke_view"))
    return render_template("postavke.html", p=postavke(), db_path=DB_PATH, dok_dir=DOK_DIR, jezici=JEZICI)


@app.route("/zaustavi", methods=["POST"])
def zaustavi():
    """Gašenje aplikacije kad radi bez prozora (Pokreni.vbs)."""
    import threading
    threading.Timer(0.5, os._exit, [0]).start()
    return render_template("zaustavljeno.html")


@app.errorhandler(404)
def nije_pronadjeno(e):
    return render_template("greska.html", poruka=t("Der gesuchte Eintrag existiert nicht.", "Traženi zapis ne postoji.")), 404


# ---------------------------------------------------------------- demo podaci

def ucitaj_demo():
    conn = sqlite3.connect(DB_PATH)
    if conn.execute("SELECT COUNT(*) FROM klijenti").fetchone()[0]:
        print("Die Datenbank enthält bereits Kunden – Demodaten wurden nicht geladen.")
        return
    t = date.today()
    c = conn.cursor()
    c.execute("INSERT INTO klijenti (naziv, oib, adresa, grad, kontakt_osoba, telefon, email) VALUES "
              "('Metallbau Huber GmbH', 'DE123456789', 'Industriestraße 5', 'München', 'Josef Huber', '089 234 5678', 'info@metallbau-huber.de')")
    k1 = c.lastrowid
    c.execute("INSERT INTO klijenti (naziv, oib, adresa, grad, kontakt_osoba, telefon) VALUES "
              "('Bäckerei Korn KG', 'DE987654321', 'Hauptstraße 12', 'Augsburg', 'Anna Weber', '0821 111 222')")
    k2 = c.lastrowid
    uredaji_demo = [
        (k1, "Drehmaschine", "Werkzeugmaschine", "Weiler", "TNP-160", "TS-0042", 1998, "Halle A", 6, 24, -400, -40),
        (k1, "Kompressor", "Druckbehälter", "Atlas Copco", "GA 11", "AC-77123", 2015, "Kompressorraum", 12, 12, -200, 10),
        (k1, "Brückenkran 5 t", "Kran", "Demag", "EKKE", "DM-5521", 2008, "Halle B", 6, 12, -90, 150),
        (k2, "Backofen", "Ofen", "Wiesheu", "Ebo 64", "WH-3310", 2019, "Produktion", 12, 24, -350, 200),
    ]
    for kid, naziv, vrsta, proizv, model, sn, god, lok, io, ii, d_odrz, d_isp_sl in uredaji_demo:
        c.execute("""INSERT INTO uredaji (klijent_id, naziv, vrsta, proizvodjac, model, serijski_broj,
                     godina_proizvodnje, lokacija, interval_odrzavanja, interval_ispitivanja)
                     VALUES (?,?,?,?,?,?,?,?,?,?)""", (kid, naziv, vrsta, proizv, model, sn, god, lok, io, ii))
        uid = c.lastrowid
        zadnje = date.fromordinal(t.toordinal() + d_odrz)
        c.execute("INSERT INTO odrzavanja (uredaj_id, datum, sljedeci_datum, vrsta, opis, izvrsio) VALUES (?,?,?,?,?,?)",
                  (uid, zadnje.isoformat(), add_months(zadnje, io).isoformat(), "Regelwartung",
                   "Schmierung, Kontrolle und Austausch von Verschleißteilen", "Service Technik"))
        sl = date.fromordinal(t.toordinal() + d_isp_sl)
        c.execute("""INSERT INTO ispitivanja (uredaj_id, predlozak_id, broj_zapisnika, vrsta, datum, sljedeci_datum,
                     ispitivac, rezultat, stavke_json) VALUES (?,?,?,?,?,?,?,?,?)""",
                  (uid, 1, f"PP-{t.year}-{uid:04d}", "Prüfung von Arbeitsmitteln",
                   add_months(sl, -ii).isoformat(), sl.isoformat(), "Markus Maier, Dipl.-Ing.", "Zadovoljava", "[]"))
    conn.commit()
    conn.close()
    print("Demodaten geladen.")


def vec_radi(port):
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


if __name__ == "__main__":
    import socket
    import threading
    if sys.stdout is None:
        # pokrenuto bez prozora (pythonw / Pokreni.vbs): ispis ide u datoteku
        log_put = os.path.join(BASE_DIR, "odrzavanje.log")
        prevelik = os.path.exists(log_put) and os.path.getsize(log_put) > 2 * 1024 * 1024
        log = open(log_put, "w" if prevelik else "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = log
        print(f"\n--- Start {sada()} ---")
    port = int(os.environ.get("PORT", 5000))
    if vec_radi(port):
        # aplikacija je već pokrenuta (npr. skrivena) – samo otvori preglednik
        if "--bez-preglednika" not in sys.argv:
            webbrowser.open(f"http://127.0.0.1:{port}")
        sys.exit(0)
    init_db()
    if "--demo" in sys.argv:
        ucitaj_demo()
    if "--bez-preglednika" not in sys.argv:
        threading.Timer(1.0, webbrowser.open, [f"http://127.0.0.1:{port}"]).start()
    print(f"Die Anwendung läuft unter http://127.0.0.1:{port}  (Beenden: Strg+C oder Einstellungen → Beenden)")
    host = "127.0.0.1"
    if "--mreza" in sys.argv:
        # ostala računala u lokalnoj mreži vide samo stranicu za prijavu zahtjeva
        host = "0.0.0.0"
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
            s.close()
        except OSError:
            ip = "<IP-Adresse dieses Computers>"
        print(f"Anfragen von anderen Computern melden: http://{ip}:{port}/prijava")
    app.run(host=host, port=port, debug=False)
