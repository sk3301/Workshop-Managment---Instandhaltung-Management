' Pokreće aplikaciju u pozadini – bez crnog prozora i bez ikone na programskoj traci.
' Ako aplikacija već radi, samo otvara preglednik. Zaustavljanje: Postavke -> Zaustavi aplikaciju.
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
mapa = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = mapa
sh.Run "pythonw """ & mapa & "\app.py""", 0, False
